from __future__ import annotations

from .rigid_body import __doc__
from .rigid_body_FEM import __doc__

__all__ = ["__doc__"]

print("importing rigid_body")